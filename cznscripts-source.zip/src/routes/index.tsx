import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { Volume2, VolumeX, Moon, Sun, Copy, Check, ExternalLink } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "cznscripts | Home" },
      { name: "description", content: "The best script hub for all your needs." },
      { property: "og:title", content: "cznscripts | Home" },
      { property: "og:description", content: "The best script hub for all your needs." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const SCRIPTS = [
  { name: "Rivals", code: 'loadstring(game:HttpGet("https://czngames.lol/Main.lua"))()' },
  { name: "Westbound", code: 'loadstring(game:HttpGet("https://czngames.lol/westbound.lua"))()' },
];

let audioCtx: AudioContext | null = null;
function clickSound() {
  try {
    audioCtx ??= new AudioContext();
    (window as unknown as { __cznAudio?: AudioContext }).__cznAudio = audioCtx;
    const ctx = audioCtx;
    const play = () => {
      const t = ctx.currentTime;
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.type = "sine";
      o.frequency.setValueAtTime(880, t);
      o.frequency.exponentialRampToValueAtTime(320, t + 0.08);
      g.gain.setValueAtTime(0.18, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.1);
      o.connect(g).connect(ctx.destination);
      o.start(t);
      o.stop(t + 0.11);
    };
    // The context can start suspended (autoplay policy) — resume before playing.
    if (ctx.state === "suspended") void ctx.resume().then(play);
    else play();
  } catch {}
}

function Rain() {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = ref.current!;
    const ctx = c.getContext("2d")!;
    let w = 0, h = 0, raf = 0;
    const resize = () => { w = c.width = innerWidth; h = c.height = innerHeight; };
    resize();
    addEventListener("resize", resize);
    const drops = Array.from({ length: 260 }, () => ({
      x: Math.random() * w, y: Math.random() * h, l: 10 + Math.random() * 18, v: 9 + Math.random() * 8,
    }));
    const loop = () => {
      ctx.clearRect(0, 0, w, h);
      ctx.strokeStyle = getComputedStyle(c).color;
      ctx.lineWidth = 1.1;
      ctx.beginPath();
      for (const d of drops) {
        ctx.moveTo(d.x, d.y);
        ctx.lineTo(d.x - 1.5, d.y + d.l);
        d.y += d.v; d.x -= 0.25;
        if (d.y > h) { d.y = -d.l; d.x = Math.random() * w; }
      }
      ctx.stroke();
      raf = requestAnimationFrame(loop);
    };
    loop();
    return () => { cancelAnimationFrame(raf); removeEventListener("resize", resize); };
  }, []);
  return <canvas ref={ref} className="pointer-events-none fixed inset-0 z-0 text-[color:var(--rain)]" />;
}

declare global { interface Window { YT: any; onYouTubeIframeAPIReady: () => void } }

function RainAudio() {
  const player = useRef<any>(null);
  const [muted, setMuted] = useState(false);
  const [vol, setVol] = useState(50);
  useEffect(() => {
    const start = () => { const p = player.current; if (p?.playVideo) { p.setVolume(vol); p.unMute(); p.playVideo(); } };
    window.onYouTubeIframeAPIReady = () => {
      player.current = new window.YT.Player("yt-rain", {
        videoId: "eTeD8DAta4c",
        playerVars: { autoplay: 1, loop: 1, playlist: "eTeD8DAta4c", controls: 0 },
        events: { onReady: (e: any) => { e.target.setVolume(50); e.target.playVideo(); } },
      });
    };
    const s = document.createElement("script");
    s.src = "https://www.youtube.com/iframe_api";
    document.body.appendChild(s);
    // Browsers block sound until the first interaction — start then.
    const once = () => { if (!muted) start(); removeEventListener("pointerdown", once); };
    addEventListener("pointerdown", once);
    return () => removeEventListener("pointerdown", once);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const toggle = () => {
    const p = player.current; if (!p) return;
    if (muted) { p.unMute(); p.playVideo(); } else p.mute();
    setMuted(!muted);
  };
  return (
    <div className="glass fixed top-4 right-4 z-20 flex items-center gap-3 rounded-full px-4 py-2">
      <div className="absolute h-0 w-0 overflow-hidden"><div id="yt-rain" /></div>
      <button onClick={toggle} aria-label={muted ? "Play rain sound" : "Mute rain sound"} className="text-foreground transition hover:text-primary">
        {muted ? <VolumeX size={16} /> : <Volume2 size={16} />}
      </button>
      <input
        type="range" min={0} max={100} value={vol} aria-label="Sound intensity" className="vol w-24"
        onChange={(e) => { const v = +e.target.value; setVol(v); player.current?.setVolume?.(v); }}
      />
      <span className="w-8 text-xs text-muted-foreground">{vol}%</span>
    </div>
  );
}

function ThemeToggle() {
  const [dark, setDark] = useState(false);
  useEffect(() => { setDark(localStorage.getItem("theme") === "dark"); }, []);
  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
    localStorage.setItem("theme", dark ? "dark" : "light");
  }, [dark]);
  return (
    <button onClick={() => setDark(!dark)} aria-label="Toggle dark mode" className="glass fixed top-4 right-[15.5rem] z-20 grid h-10 w-10 place-items-center rounded-full text-foreground transition hover:text-primary">
      {dark ? <Sun size={16} /> : <Moon size={16} />}
    </button>
  );
}

function Visitors() {
  const [n, setN] = useState<number | null>(null);
  useEffect(() => {
    const ch = supabase.channel("site-visitors", { config: { presence: { key: crypto.randomUUID() } } });
    ch.on("presence", { event: "sync" }, () => setN(Object.keys(ch.presenceState()).length))
      .subscribe((status) => { if (status === "SUBSCRIBED") ch.track({ at: Date.now() }); });
    return () => { supabase.removeChannel(ch); };
  }, []);
  return (
    <div className="glass fixed bottom-4 left-1/2 z-20 flex -translate-x-1/2 items-center gap-2 rounded-full px-4 py-1.5 text-xs tracking-wide text-foreground">
      <span className="pulse-dot h-1.5 w-1.5 rounded-full bg-primary" />
      <span className="font-semibold tabular-nums">{n ?? "–"}</span>
      <span className="uppercase text-muted-foreground">online now</span>
    </div>
  );
}

function ScriptRow({ name, code }: { name: string; code: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <div className="glass flex items-stretch rounded-2xl p-2 transition hover:-translate-y-0.5">
      <div className="flex min-w-[120px] items-center justify-center border-r border-[color:var(--glass-border)] px-4 text-sm font-semibold uppercase tracking-widest text-primary">
        {name}
      </div>
      <input readOnly value={code} className="font-code min-w-0 flex-1 truncate bg-transparent px-4 py-3 text-sm text-foreground outline-none" />
      <button
        onClick={() => { navigator.clipboard.writeText(code); setCopied(true); setTimeout(() => setCopied(false), 1500); }}
        className="flex items-center gap-2 rounded-xl bg-primary px-5 text-sm font-semibold text-primary-foreground transition hover:opacity-90 active:scale-95"
      >
        {copied ? <Check size={15} /> : <Copy size={15} />}
        {copied ? "Copied" : "Copy"}
      </button>
    </div>
  );
}

function Index() {
  useEffect(() => {
    const h = (e: MouseEvent) => { if ((e.target as HTMLElement).closest("button,a")) clickSound(); };
    addEventListener("click", h);
    return () => removeEventListener("click", h);
  }, []);
  return (
    <div className="sky relative min-h-screen overflow-hidden text-foreground">
      <Rain />
      <div className="fixed top-5 left-6 z-20 text-sm font-light tracking-[0.35em] text-foreground/80">cznscripts</div>
      <ThemeToggle />
      <RainAudio />
      <main className="relative z-10 flex min-h-screen flex-col items-center justify-center gap-6 px-6 text-center">
        <div className="mb-2 space-y-3">
          <h1 className="text-4xl font-semibold tracking-tight md:text-5xl">{"\n"}</h1>
          <p className="text-sm text-muted-foreground">{"\n"}</p>
        </div>
        <div className="flex w-full max-w-2xl flex-col gap-4">
          {SCRIPTS.map((s) => <ScriptRow key={s.name} {...s} />)}
        </div>
        <a href="https://discord.gg/cznscripts" target="_blank" rel="noreferrer" className="glass group flex items-center gap-2 rounded-full px-7 py-3 font-semibold text-primary transition hover:-translate-y-0.5">
          {"Join our Discord\n\n"}
          <ExternalLink size={15} className="transition group-hover:translate-x-0.5" />
          <span className="text-xs font-normal text-muted-foreground">{"\n"}</span>
        </a>
      </main>
      <Visitors />
    </div>
  );
}
